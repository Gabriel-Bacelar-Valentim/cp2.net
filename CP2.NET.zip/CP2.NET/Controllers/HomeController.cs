using CP1.NET.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CP1.NET.Controllers
{
    public class HomeController : Controller
    {

        public IActionResult Index()
        {



            return View();
        }
    }
}

