﻿namespace CP1.NET.Models;
using System;
using System.Collections.Generic;

public class Carrinho
{
    private List<Produto> Produtos { get; set; }

    public Carrinho()
    {
        Produtos = new List<Produto>(); // Inicialize a lista no construtor
    }

    internal void AddCarrinho(Produto produto)
    {
        Produtos.Add(produto);
        Console.WriteLine($"{produto.Nome} adicionado ao carrinho.");
    }

    internal void ExibirCarrinho()
    {
        Console.WriteLine("Carrinho de Compras:\n");
        foreach (var produto in Produtos)
        {
            Console.WriteLine(produto);
        }
    }
}


