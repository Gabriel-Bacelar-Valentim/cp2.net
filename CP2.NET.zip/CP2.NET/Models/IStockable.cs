﻿namespace CP1.NET.Models
{
    public interface IStockable
    {
        
        void AtualizarEstoque(int quantidade);
    }
}
