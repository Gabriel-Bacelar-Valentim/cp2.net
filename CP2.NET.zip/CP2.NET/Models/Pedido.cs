﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations.Schema;

namespace CP1.NET.Models
{
    [Table("CP2_TB_PEDIDO")]
    public class Pedido
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PedidoId { get; set; }
        [Required]
        public DateTime Data { get; set; }

        [Required]
        public int ClienteId { get; set; }
        
        [Required(ErrorMessage = "Cliente esta invalido")]
        public Cliente Cliente { get; set; }
        
        [Required(ErrorMessage = "O item esta invalido")]
        public List<ItemPedido> Itens { get; set; }
    }
}
