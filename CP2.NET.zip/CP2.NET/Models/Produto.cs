﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CP1.NET.Models
{

    [Table("CP2_TB_PRODUTO")]
    public class Produto : IStockable
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Nome invalido")]
        public string Nome { get; set; }

        [Range(50, 300, ErrorMessage = "Preco invalido")]
        public Double Preco { get; set; }
        public int QuantidadeEstoque { get; set; }

        public Produto( int id, string nome, Double preco, int quantidadeEstoque)
        {
            Id = id;
            Nome = nome;
            Preco = preco;
            QuantidadeEstoque = quantidadeEstoque;
        }

        public override string ToString()
        {
            return $"{Nome} - Preço: {Preco:C}, Estoque: {QuantidadeEstoque} unidades";
        }

        protected void AjustarEstoque(int quantidade)
        {
            QuantidadeEstoque += quantidade;
        }

        public void AtualizarEstoque(int quantidade)
        {
            AjustarEstoque(quantidade);
        }

    }
}
